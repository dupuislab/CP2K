# signal trapping
trap 'error_handler ${LINENO}' ERR
