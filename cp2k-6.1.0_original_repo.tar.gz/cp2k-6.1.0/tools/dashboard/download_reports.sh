#!/bin/bash

wget --no-verbose -nH -Nxi http://dashboard.cp2k.org/archive/list_recent.txt

#EOF
