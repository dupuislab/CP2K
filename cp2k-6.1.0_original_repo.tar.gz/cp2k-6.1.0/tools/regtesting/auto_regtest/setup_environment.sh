# CP2K regtesrter
# setup_environment.sh
# Any changes to system PATH or LD_LIBRARY_PATH should be here

#export MPI_ROOT=/opt/platform_mpi/
#export PATH=/shared/gcc-4.7.2/bin/:/opt/platform_mpi/bin:$PATH

#export LD_LIBRARY_PATH=/home/w02/cp2ktest/lib/mpc/lib/:/home/w02/cp2ktest/lib/mpfr/lib/:/home/w02/cp2ktest/lib/gmp/lib/:/shared/gcc-4.7.2/lib64/:/shared/acml/5.3.0/gfortran64_fma4/lib/:$LD_LIBRARY_PATH
